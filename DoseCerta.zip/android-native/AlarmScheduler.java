package br.com.dosecerta.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class AlarmScheduler {
    static final String PREFS = "dosecerta_native_alarms";
    static final String RULES = "rules";
    static final String ACTIONS = "actions";
    static final String ACTIVE = "active";

    private AlarmScheduler() {}

    static void replace(Context context, JSONArray rules) throws JSONException {
        JSONArray old = getRules(context);
        for (int i = 0; i < old.length(); i++) {
            JSONObject item = old.optJSONObject(i);
            if (item != null) cancel(context, item.optString("medicineId"));
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(RULES, rules.toString()).apply();

        for (int i = 0; i < rules.length(); i++) {
            JSONObject item = rules.optJSONObject(i);
            if (item != null) schedule(context, item);
        }
    }

    static JSONArray getRules(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(RULES, "[]");
        try { return new JSONArray(raw); }
        catch (JSONException ignored) { return new JSONArray(); }
    }

    static void rescheduleAll(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) return;
        JSONArray rules = getRules(context);
        for (int i = 0; i < rules.length(); i++) {
            JSONObject item = rules.optJSONObject(i);
            if (item != null) schedule(context, item);
        }
    }

    static void advanceAndSchedule(Context context, String medicineId, long dueAt) {
        JSONArray rules = getRules(context);
        long now = System.currentTimeMillis();
        for (int i = 0; i < rules.length(); i++) {
            JSONObject item = rules.optJSONObject(i);
            if (item == null || !medicineId.equals(item.optString("medicineId"))) continue;
            long interval = item.optLong("intervalMs", 0);
            if (interval <= 0) return;
            long next = item.optLong("nextAt", dueAt) + interval;
            while (next <= now) next += interval;
            try {
                item.put("nextAt", next);
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(RULES, rules.toString()).apply();
                schedule(context, item);
            } catch (JSONException ignored) {}
            return;
        }
    }

    static void schedule(Context context, JSONObject rule) {
        long at = rule.optLong("nextAt", 0);
        String id = rule.optString("medicineId", "");
        if (at <= 0 || id.isEmpty()) return;

        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) return;

        Intent intent = new Intent(context, DoseAlarmReceiver.class)
            .setAction("br.com.dosecerta.ALARM")
            .setData(Uri.parse("dosecerta://alarm/" + Uri.encode(id)))
            .putExtra("medicineId", id)
            .putExtra("medicineName", rule.optString("medicineName", "Medicamento"))
            .putExtra("dueAt", at)
            .putExtra("intervalMs", rule.optLong("intervalMs", 0));

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent operation = PendingIntent.getBroadcast(context, id.hashCode(), intent, flags);

        Intent showIntent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        PendingIntent show = PendingIntent.getActivity(context, 91001, showIntent,
            flags | PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(at, show);
        manager.setAlarmClock(info, operation);
    }

    static void cancel(Context context, String id) {
        if (id == null || id.isEmpty()) return;
        Intent intent = new Intent(context, DoseAlarmReceiver.class)
            .setAction("br.com.dosecerta.ALARM")
            .setData(Uri.parse("dosecerta://alarm/" + Uri.encode(id)));
        int flags = PendingIntent.FLAG_NO_CREATE;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent operation = PendingIntent.getBroadcast(context, id.hashCode(), intent, flags);
        if (operation != null) {
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            manager.cancel(operation);
            operation.cancel();
        }
    }

    static synchronized void addActive(Context context, String medicineId, String medicineName,
                                       long dueAt, long intervalMs) {
        JSONArray active = getActiveAlarms(context);
        for (int i = 0; i < active.length(); i++) {
            JSONObject item = active.optJSONObject(i);
            if (item != null && medicineId.equals(item.optString("medicineId"))
                && dueAt == item.optLong("dueAt")) return;
        }
        JSONObject item = new JSONObject();
        try {
            item.put("medicineId", medicineId);
            item.put("medicineName", medicineName);
            item.put("dueAt", dueAt);
            item.put("intervalMs", intervalMs);
            active.put(item);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(ACTIVE, active.toString()).apply();
        } catch (JSONException ignored) {}
    }

    static synchronized JSONArray getActiveAlarms(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(ACTIVE, "[]");
        try { return new JSONArray(raw); }
        catch (JSONException ignored) { return new JSONArray(); }
    }

    static synchronized void rebaseAfterConfirmation(Context context, String medicineId, long confirmedAt) {
        JSONArray rules = getRules(context);
        for (int i = 0; i < rules.length(); i++) {
            JSONObject rule = rules.optJSONObject(i);
            if (rule == null || !medicineId.equals(rule.optString("medicineId"))) continue;
            long interval = rule.optLong("intervalMs", 0);
            if (interval <= 0) return;
            try {
                rule.put("nextAt", confirmedAt + interval);
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(RULES, rules.toString()).apply();
                schedule(context, rule);
            } catch (JSONException ignored) {}
            return;
        }
    }

    static synchronized void clearActiveAlarms(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(ACTIVE, "[]").apply();
    }

    static synchronized void addAction(Context context, String medicineId, String medicineName,
                                        long dueAt, String action) {
        JSONArray actions = consumeOrReadActions(context, false);
        JSONObject event = new JSONObject();
        try {
            event.put("medicineId", medicineId);
            event.put("medicineName", medicineName);
            event.put("dueAt", dueAt);
            event.put("action", action);
            event.put("recordedAt", System.currentTimeMillis());
            actions.put(event);
        } catch (JSONException ignored) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(ACTIONS, actions.toString()).apply();
    }

    static synchronized JSONArray consumeActions(Context context) {
        return consumeOrReadActions(context, true);
    }

    private static JSONArray consumeOrReadActions(Context context, boolean clear) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(ACTIONS, "[]");
        JSONArray result;
        try { result = new JSONArray(raw); }
        catch (JSONException ignored) { result = new JSONArray(); }
        if (clear) context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(ACTIONS, "[]").apply();
        return result;
    }
}
