package br.com.dosecerta.app;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class DoseAlarmActivity extends Activity {
    private TextView medicinesView;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prepareWindow();
        buildScreen();
        updateMedicines();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        updateMedicines();
    }

    private void prepareWindow() {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
            | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 48, 32, 48);
        root.setBackgroundColor(Color.rgb(5, 5, 5));

        TextView eyebrow = new TextView(this);
        eyebrow.setText("DOSECERTA");
        eyebrow.setTextColor(Color.rgb(166, 255, 0));
        eyebrow.setTextSize(14);
        eyebrow.setLetterSpacing(0.18f);
        eyebrow.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("Hora do medicamento");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 28, 0, 12);

        medicinesView = new TextView(this);
        medicinesView.setTextColor(Color.rgb(166, 255, 0));
        medicinesView.setTextSize(23);
        medicinesView.setGravity(Gravity.CENTER);
        medicinesView.setPadding(0, 0, 0, 44);

        Button confirm = new Button(this);
        confirm.setText("CONFIRMAR DOSE");
        confirm.setAllCaps(false);
        confirm.setTextSize(16);
        confirm.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(166, 255, 0)));
        confirm.setTextColor(Color.BLACK);
        confirm.setOnClickListener(v -> finishAlarm(DoseAlarmService.ACTION_CONFIRM));

        Button stop = new Button(this);
        stop.setText("Desligar alarme");
        stop.setAllCaps(false);
        stop.setTextSize(15);
        stop.setOnClickListener(v -> finishAlarm(DoseAlarmService.ACTION_STOP));

        root.addView(eyebrow, new LinearLayout.LayoutParams(-1, -2));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        root.addView(medicinesView, new LinearLayout.LayoutParams(-1, -2));
        root.addView(confirm, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-1, -2);
        stopParams.topMargin = 16;
        root.addView(stop, stopParams);
        setContentView(root);
    }

    private void updateMedicines() {
        JSONArray active = AlarmScheduler.getActiveAlarms(this);
        StringBuilder names = new StringBuilder();
        for (int i = 0; i < active.length(); i++) {
            JSONObject item = active.optJSONObject(i);
            if (item == null) continue;
            if (names.length() > 0) names.append("\n");
            names.append("• ").append(item.optString("medicineName", "Medicamento"));
        }
        medicinesView.setText(names.length() == 0 ? "Medicamento" : names.toString());
    }

    private void finishAlarm(String action) {
        Intent service = new Intent(this, DoseAlarmService.class).setAction(action);
        startService(service);
        finish();
    }
}
