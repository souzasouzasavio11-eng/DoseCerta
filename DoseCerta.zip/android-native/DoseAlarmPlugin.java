package br.com.dosecerta.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;

@CapacitorPlugin(name = "DoseAlarm")
public class DoseAlarmPlugin extends Plugin {
    @PluginMethod
    public void schedule(PluginCall call) {
        JSArray alarms = call.getArray("alarms");
        if (alarms == null) {
            call.reject("Lista de alarmes ausente.");
            return;
        }

        AlarmManager manager = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
            call.reject("A permissão de alarmes exatos não está ativa.");
            return;
        }

        try {
            JSONArray json = new JSONArray(alarms.toString());
            AlarmScheduler.replace(getContext(), json);
            JSObject result = new JSObject();
            result.put("scheduled", json.length());
            call.resolve(result);
        } catch (Exception error) {
            call.reject("Não foi possível programar os alarmes.", error);
        }
    }

    @PluginMethod
    public void getActions(PluginCall call) {
        try {
            JSONArray actions = AlarmScheduler.consumeActions(getContext());
            JSObject result = new JSObject();
            result.put("actions", actions);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("Não foi possível recuperar as ações do alarme.", error);
        }
    }

    @PluginMethod
    public void checkFullScreenIntentPermission(PluginCall call) {
        boolean granted = true;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager manager = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            granted = manager.canUseFullScreenIntent();
        }
        JSObject result = new JSObject();
        result.put("granted", granted);
        call.resolve(result);
    }

    @PluginMethod
    public void openFullScreenIntentSettings(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:" + getContext().getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
            } catch (Exception error) {
                call.reject("Não foi possível abrir a configuração de tela cheia.", error);
                return;
            }
        }
        call.resolve();
    }
}
