package br.com.dosecerta.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class DoseAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String id = intent.getStringExtra("medicineId");
        String name = intent.getStringExtra("medicineName");
        long dueAt = intent.getLongExtra("dueAt", System.currentTimeMillis());
        long interval = intent.getLongExtra("intervalMs", 0);
        if (id == null || id.isEmpty()) return;

        AlarmScheduler.advanceAndSchedule(context, id, dueAt);

        Intent service = new Intent(context, DoseAlarmService.class)
            .setAction(DoseAlarmService.ACTION_RING)
            .putExtra("medicineId", id)
            .putExtra("medicineName", name == null ? "Medicamento" : name)
            .putExtra("dueAt", dueAt)
            .putExtra("intervalMs", interval);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service);
            else context.startService(service);
        } catch (Exception ignored) {
            // O alarme permanece registrado para a próxima ocorrência.
        }
    }
}
