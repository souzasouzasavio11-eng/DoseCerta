package br.com.dosecerta.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

public class DoseAlarmService extends Service {
    static final String ACTION_RING = "br.com.dosecerta.RING";
    static final String ACTION_STOP = "br.com.dosecerta.STOP";
    static final String ACTION_CONFIRM = "br.com.dosecerta.CONFIRM";
    private static final String CHANNEL_ID = "dosecerta_persistent_alarm";
    private static final int NOTIFICATION_ID = 7301;

    private MediaPlayer player;
    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();

        if (ACTION_STOP.equals(action) || ACTION_CONFIRM.equals(action)) {
            JSONArray active = AlarmScheduler.getActiveAlarms(this);
            String result = ACTION_CONFIRM.equals(action) ? "confirmed" : "dismissed";
            for (int i = 0; i < active.length(); i++) {
                JSONObject item = active.optJSONObject(i);
                if (item == null) continue;
                String id = item.optString("medicineId");
                long confirmedAt = System.currentTimeMillis();
                if (ACTION_CONFIRM.equals(action)) {
                    AlarmScheduler.rebaseAfterConfirmation(this, id, confirmedAt);
                }
                AlarmScheduler.addAction(this, id, item.optString("medicineName"),
                    item.optLong("dueAt"), result);
            }
            AlarmScheduler.clearActiveAlarms(this);
            stopRinging();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (intent != null && ACTION_RING.equals(action)) {
            String id = intent.getStringExtra("medicineId");
            String name = intent.getStringExtra("medicineName");
            long dueAt = intent.getLongExtra("dueAt", System.currentTimeMillis());
            if (id != null && !id.isEmpty()) {
                long interval = intent.getLongExtra("intervalMs", 0);
                AlarmScheduler.addActive(this, id, name == null ? "Medicamento" : name,
                    dueAt, interval);
            }
        }

        if (AlarmScheduler.getActiveAlarms(this).length() == 0) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        if (player == null || !player.isPlaying()) startRinging();
        else {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.notify(NOTIFICATION_ID, notification);
        }
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                "Alarmes do DoseCerta", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Alarme persistente dos horários de medicamentos");
            channel.setSound(null, null);
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private PendingIntent serviceAction(String action, int requestCode) {
        Intent intent = new Intent(this, DoseAlarmService.class).setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getService(this, requestCode, intent, flags);
    }

    private String activeNames() {
        JSONArray active = AlarmScheduler.getActiveAlarms(this);
        StringBuilder names = new StringBuilder();
        for (int i = 0; i < active.length(); i++) {
            JSONObject item = active.optJSONObject(i);
            if (item == null) continue;
            if (names.length() > 0) names.append(", ");
            names.append(item.optString("medicineName", "Medicamento"));
        }
        return names.length() == 0 ? "Medicamento" : names.toString();
    }

    private Notification buildNotification() {
        Intent screen = new Intent(this, DoseAlarmActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent fullScreen = PendingIntent.getActivity(this, 7302, screen, flags);

        String names = activeNames();
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Hora do medicamento")
            .setContentText(names + " — o alarme está tocando")
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setPriority(Notification.PRIORITY_MAX)
            .setFullScreenIntent(fullScreen, true)
            .setContentIntent(fullScreen)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Desligar",
                serviceAction(ACTION_STOP, 7303))
            .addAction(android.R.drawable.checkbox_on_background, "Confirmar dose",
                serviceAction(ACTION_CONFIRM, 7304));
        return builder.build();
    }

    private void startRinging() {
        stopRinging();
        try {
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build());
            player.setDataSource(this, sound);
            player.setLooping(true);
            player.prepare();
            player.start();
            PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DoseCerta:AlarmAudio");
            wakeLock.acquire();
        } catch (Exception error) {
            stopRinging();
        }
    }

    private void stopRinging() {
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            wakeLock = null;
        }
    }

    @Override
    public void onDestroy() {
        stopRinging();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
