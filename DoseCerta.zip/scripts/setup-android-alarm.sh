#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID="$ROOT/android"
PKG_DIR="$ANDROID/app/src/main/java/br/com/dosecerta/app"
MANIFEST="$ANDROID/app/src/main/AndroidManifest.xml"

if [[ ! -f "$MANIFEST" ]]; then
  echo "AndroidManifest.xml não encontrado. Execute este script depois de npx cap add android."
  exit 1
fi

mkdir -p "$PKG_DIR"
cp "$ROOT/android-native/"*.java "$PKG_DIR/"

cat > "$PKG_DIR/MainActivity.java" <<'JAVA'
package br.com.dosecerta.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(DoseAlarmPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
JAVA

python3 - <<'PY'
from pathlib import Path
p = Path("android/app/src/main/AndroidManifest.xml")
s = p.read_text()
permissions = [
    'android.permission.SCHEDULE_EXACT_ALARM',
    'android.permission.RECEIVE_BOOT_COMPLETED',
    'android.permission.FOREGROUND_SERVICE',
    'android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK',
    'android.permission.USE_FULL_SCREEN_INTENT',
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.WAKE_LOCK',
    'android.permission.VIBRATE',
]
for permission in permissions:
    tag = f'<uses-permission android:name="{permission}" />'
    if tag not in s:
        s = s.replace('<application', f'    {tag}\n    <application', 1)

components = '''
        <activity
            android:name=".DoseAlarmActivity"
            android:exported="false"
            android:excludeFromRecents="true"
            android:launchMode="singleTop"
            android:showWhenLocked="true"
            android:turnScreenOn="true"
            android:theme="@android:style/Theme.Material.Light.NoActionBar" />
        <service
            android:name=".DoseAlarmService"
            android:exported="false"
            android:foregroundServiceType="mediaPlayback" />
        <receiver
            android:name=".DoseAlarmReceiver"
            android:exported="false" />
        <receiver
            android:name=".DoseBootReceiver"
            android:enabled="true"
            android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
                <action android:name="android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" />
            </intent-filter>
        </receiver>
'''
if '.DoseAlarmService' not in s:
    s = s.replace('</application>', components + '    </application>', 1)
p.write_text(s)
PY

echo "Camada nativa de alarme persistente instalada no projeto Android."
