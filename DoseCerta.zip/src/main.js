const STORAGE_MEDS = 'dosecerta_medications_v2';
const STORAGE_HISTORY = 'dosecerta_history_v2';

let medications = JSON.parse(localStorage.getItem(STORAGE_MEDS) || '[]');
let history = JSON.parse(localStorage.getItem(STORAGE_HISTORY) || '[]');

const medListEl = document.getElementById('med-list');
const emptyStateEl = document.getElementById('empty-state');
const historyListEl = document.getElementById('history-list');
const emptyHistoryEl = document.getElementById('empty-history');

const modalEl = document.getElementById('med-modal');
const modalTitleEl = document.getElementById('modal-title');
const medForm = document.getElementById('med-form');
const medIdInput = document.getElementById('med-id');
const medNameInput = document.getElementById('med-name');
const medDosageInput = document.getElementById('med-dosage');
const medStartTimeInput = document.getElementById('med-start-time');
const medIntervalInput = document.getElementById('med-interval');

const btnAddMed = document.getElementById('btn-add-med');
const btnCancelModal = document.getElementById('btn-cancel-modal');
const btnClearHistory = document.getElementById('btn-clear-history');

btnAddMed.addEventListener('click', () => openModal());
btnCancelModal.addEventListener('click', closeModal);
btnClearHistory.addEventListener('click', clearHistory);
medForm.addEventListener('submit', handleSaveMedication);

function calculateNextDose(lastDoseIso, intervalHours) {
  const intervalMs = parseFloat(intervalHours) * 60 * 60 * 1000;
  let nextTime = new Date(lastDoseIso).getTime();
  const now = Date.now();

  while (nextTime <= now) {
    nextTime += intervalMs;
  }

  return new Date(nextTime);
}

function formatNextDoseText(dateObj) {
  const now = new Date();
  const isToday = dateObj.toDateString() === now.toDateString();
  
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const isTomorrow = dateObj.toDateString() === tomorrow.toDateString();

  const hours = String(dateObj.getHours()).padStart(2, '0');
  const minutes = String(dateObj.getMinutes()).padStart(2, '0');
  const timeStr = `${hours}:${minutes}`;

  if (isToday) return `Hoje às ${timeStr}`;
  if (isTomorrow) return `Amanhã às ${timeStr}`;

  const day = String(dateObj.getDate()).padStart(2, '0');
  const month = String(dateObj.getMonth() + 1).padStart(2, '0');
  return `${day}/${month} às ${timeStr}`;
}

function getCountdownText(nextDate) {
  const diffMs = nextDate.getTime() - Date.now();
  if (diffMs <= 0) return 'Agora!';

  const totalSec = Math.floor(diffMs / 1000);
  const hours = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;

  if (hours > 0) return `em ${hours}h ${mins}m`;
  if (mins > 0) return `em ${mins}m ${secs}s`;
  return `em ${secs}s`;
}

async function scheduleNativeAlarm(med, nextDoseDate) {
  try {
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.DoseAlarmPlugin) {
      await window.Capacitor.Plugins.DoseAlarmPlugin.scheduleAlarm({
        id: med.id,
        title: `Hora do medicamento: ${med.name}`,
        dosage: med.dosage || '',
        time: nextDoseDate.getTime()
      });
    }
  } catch (err) {
    console.warn('Plugin de alarme nativo indisponível:', err);
  }
}

function renderMedications() {
  medListEl.innerHTML = '';

  if (medications.length === 0) {
    emptyStateEl.classList.remove('hidden');
    return;
  }

  emptyStateEl.classList.add('hidden');

  medications.forEach(med => {
    const nextDoseDate = calculateNextDose(med.lastDoseTime, med.intervalHours);
    scheduleNativeAlarm(med, nextDoseDate);

    const card = document.createElement('div');
    card.className = 'med-card';

    card.innerHTML = `
      <div class="med-card-top">
        <div class="med-info">
          <h3>${escapeHtml(med.name)}</h3>
          <p class="med-dosage">${escapeHtml(med.dosage || 'Sem especificação')} • A cada ${med.intervalHours}h</p>
        </div>
        <div class="med-card-actions">
          <button class="btn-action btn-edit" data-id="${med.id}">Editar</button>
          <button class="btn-action btn-danger btn-delete" data-id="${med.id}">Excluir</button>
        </div>
      </div>

      <div class="med-time-info">
        <div>
          <div class="next-dose-label">Próxima Dose</div>
          <div class="next-dose-value">${formatNextDoseText(nextDoseDate)}</div>
        </div>
        <div class="countdown-box">
          <div class="countdown-label">Faltam</div>
          <div class="countdown-value" data-countdown="${nextDoseDate.getTime()}">${getCountdownText(nextDoseDate)}</div>
        </div>
      </div>

      <button class="btn-confirm" data-id="${med.id}">✓ Confirmar Dose Tomada</button>
    `;

    medListEl.appendChild(card);
  });

  document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', (e) => openModal(e.target.dataset.id));
  });

  document.querySelectorAll('.btn-delete').forEach(btn => {
    btn.addEventListener('click', (e) => deleteMedication(e.target.dataset.id));
  });

  document.querySelectorAll('.btn-confirm').forEach(btn => {
    btn.addEventListener('click', (e) => confirmDose(e.target.dataset.id));
  });
}

function renderHistory() {
  historyListEl.innerHTML = '';

  if (history.length === 0) {
    emptyHistoryEl.classList.remove('hidden');
    return;
  }

  emptyHistoryEl.classList.add('hidden');

  history.slice(0, 15).forEach(item => {
    const li = document.createElement('li');
    li.className = 'history-item';
    const dateObj = new Date(item.timestamp);
    const dateStr = `${String(dateObj.getDate()).padStart(2, '0')}/${String(dateObj.getMonth() + 1).padStart(2, '0')} às ${String(dateObj.getHours()).padStart(2, '0')}:${String(dateObj.getMinutes()).padStart(2, '0')}`;

    li.innerHTML = `
      <span class="history-name">${escapeHtml(item.name)}</span>
      <span class="history-time">${dateStr}</span>
    `;
    historyListEl.appendChild(li);
  });
}

function handleSaveMedication(e) {
  e.preventDefault();

  const id = medIdInput.value || 'med_' + Date.now();
  const name = medNameInput.value.trim();
  const dosage = medDosageInput.value.trim();
  const startTime = medStartTimeInput.value;
  const intervalHours = parseFloat(medIntervalInput.value);

  if (!name || !startTime || !intervalHours) return;

  const existingIndex = medications.findIndex(m => m.id === id);
  const medData = {
    id,
    name,
    dosage,
    lastDoseTime: new Date(startTime).toISOString(),
    intervalHours
  };

  if (existingIndex >= 0) {
    medications[existingIndex] = medData;
  } else {
    medications.push(medData);
  }

  saveMeds();
  closeModal();
  renderMedications();
}

function openModal(id = null) {
  medForm.reset();
  if (id) {
    const med = medications.find(m => m.id === id);
    if (med) {
      modalTitleEl.textContent = 'Editar Medicamento';
      medIdInput.value = med.id;
      medNameInput.value = med.name;
      medDosageInput.value = med.dosage || '';
      
      const localDate = new Date(med.lastDoseTime);
      localDate.setMinutes(localDate.getMinutes() - localDate.getTimezoneOffset());
      medStartTimeInput.value = localDate.toISOString().slice(0, 16);
      
      medIntervalInput.value = med.intervalHours;
    }
  } else {
    modalTitleEl.textContent = 'Novo Medicamento';
    medIdInput.value = '';
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    medStartTimeInput.value = now.toISOString().slice(0, 16);
  }

  modalEl.classList.remove('hidden');
}

function closeModal() {
  modalEl.classList.add('hidden');
}

function deleteMedication(id) {
  if (confirm('Deseja realmente excluir este medicamento?')) {
    medications = medications.filter(m => m.id !== id);
    saveMeds();
    renderMedications();
  }
}

function confirmDose(id) {
  const med = medications.find(m => m.id === id);
  if (!med) return;

  const now = new Date();
  med.lastDoseTime = now.toISOString();

  history.unshift({
    name: med.name,
    timestamp: now.toISOString()
  });

  saveMeds();
  saveHistory();

  renderMedications();
  renderHistory();
}

function clearHistory() {
  if (history.length === 0) return;
  if (confirm('Limpar todo o histórico de doses?')) {
    history = [];
    saveHistory();
    renderHistory();
  }
}

function saveMeds() {
  localStorage.setItem(STORAGE_MEDS, JSON.stringify(medications));
}

function saveHistory() {
  localStorage.setItem(STORAGE_HISTORY, JSON.stringify(history));
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, match => {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
    return map[match];
  });
}

setInterval(() => {
  document.querySelectorAll('[data-countdown]').forEach(el => {
    const targetMs = parseInt(el.dataset.countdown, 10);
    if (!isNaN(targetMs)) {
      el.textContent = getCountdownText(new Date(targetMs));
    }
  });
}, 1000);

renderMedications();
renderHistory();
