
import './style.css';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';

const STORAGE_KEY = 'dosecerta.v1';
const HISTORY_KEY = 'dosecerta.history.v1';
const SETTINGS_KEY = 'dosecerta.settings.v1';
const app = document.querySelector('#app');

function load(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}

function pad(n) {
  return String(n).padStart(2, '0');
}

function localDateKey(date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function dateFromKey(key) {
  const [y, m, d] = String(key).split('-').map(Number);
  return new Date(y, m - 1, d);
}

function toLocalInput(date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function parseLocal(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function makeId() {
  return crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[c]);
}

function fmt(date) {
  if (!date) return '—';
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
}

function fmtTime(date) {
  if (!date) return '—';
  return new Intl.DateTimeFormat('pt-BR', {
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
}

function relative(date) {
  if (!date) return '';
  const diff = date.getTime() - Date.now();

  if (diff <= 0) return 'Horário já passou';

  const mins = Math.ceil(diff / 60000);
  const hours = Math.floor(mins / 60);
  const minutes = mins % 60;

  if (!hours) return `Daqui a ${minutes} min`;
  if (!minutes) return `Daqui a ${hours} h`;

  return `Daqui a ${hours} h e ${minutes} min`;
}

function nextDose(lastDose, intervalHours) {
  const interval = Number(intervalHours) * 3600000;

  if (!lastDose || !Number.isFinite(interval) || interval <= 0) {
    return null;
  }

  return new Date(lastDose.getTime() + interval);
}

/* Carregamento e compatibilidade com os dados antigos */

let medicines = load(STORAGE_KEY, []).map(m => ({
  ...m,
  stock: m.stock === undefined ? null : m.stock,
  quantityPerDose: Number(m.quantityPerDose) || 1,
  stockAlert: Number(m.stockAlert) || 5
}));

let history = load(HISTORY_KEY, []).map(h => ({
  ...h,
  status: h.status || 'tomada',
  scheduledAt: h.scheduledAt || h.takenAt || new Date().toISOString(),
  recordedAt: h.recordedAt || h.takenAt || new Date().toISOString()
}));

let settings = load(SETTINGS_KEY, {
  selectedDate: localDateKey(new Date())
});

if (!settings.selectedDate) {
  settings.selectedDate = localDateKey(new Date());
}

let activeTab = 'agenda';
let searchTerm = '';
let statusFilter = 'todos';
let channelReady = false;

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(medicines));
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function persistAndRender() {
  save();
  render();
  refreshNotifications();
}

function capsuleSvg() {
  return `
    <svg viewBox="0 0 48 48" aria-hidden="true">
      <g transform="rotate(-45 24 24)">
        <rect x="11" y="5" width="26" height="38" rx="13"></rect>
        <path d="M11 24h26"></path>
      </g>
    </svg>
  `;
}

/* Controle dos registros de doses */

function doseKey(medicineId, dueAt) {
  return `${medicineId}::${new Date(dueAt).toISOString()}`;
}

function doseRecord(medicineId, dueAt) {
  const key = doseKey(medicineId, dueAt);

  return history.find(h =>
    h.doseKey === key ||
    (
      h.medicineId === medicineId &&
      new Date(h.scheduledAt).getTime() === new Date(dueAt).getTime()
    )
  );
}

function getStatus(medicineId, dueAt) {
  const record = doseRecord(medicineId, dueAt);

  if (record) return record.status;

  return dueAt.getTime() < Date.now()
    ? 'atrasada'
    : 'agendada';
}

function recordDose(med, dueAt, status) {
  const key = doseKey(med.id, dueAt);
  const existing = history.findIndex(h =>
    h.doseKey === key ||
    (
      h.medicineId === med.id &&
      new Date(h.scheduledAt).getTime() === dueAt.getTime()
    )
  );

  const item = {
    id: existing >= 0 ? history[existing].id : makeId(),
    doseKey: key,
    medicineId: med.id,
    medicineName: med.name,
    scheduledAt: dueAt.toISOString(),
    recordedAt: new Date().toISOString(),
    status,
    quantity: Number(med.quantityPerDose) || 1
  };

  if (existing >= 0) {
    history[existing] = item;
  } else {
    history.unshift(item);
  }

  if (status === 'tomada') {
    if (med.stock !== null && med.stock !== undefined) {
      med.stock = Math.max(
        0,
        Number(med.stock) - item.quantity
      );
    }

    // Mantém a última dose como referência do próximo intervalo.
    med.lastDose = toLocalInput(new Date());
  }

  history = history.slice(0, 2000);
  persistAndRender();
}

function markDose(medicineId, dueTimestamp, status) {
  const med = medicines.find(m => m.id === medicineId);

  if (!med) return;

  const dueAt = new Date(Number(dueTimestamp));

  if (Number.isNaN(dueAt.getTime())) return;

  if (
    status === 'tomada' &&
    med.stock !== null &&
    Number(med.stock) < Number(med.quantityPerDose || 1)
  ) {
    if (!confirm('O estoque cadastrado é insuficiente. Deseja registrar mesmo assim?')) {
      return;
    }
  }

  recordDose(med, dueAt, status);
}

/* Cálculo da agenda diária */

function occurrencesForDay(med, dayKey) {
  const last = parseLocal(med.lastDose);
  const interval = Number(med.intervalHours) * 3600000;

  if (!last || !Number.isFinite(interval) || interval <= 0) {
    return [];
  }

  const start = dateFromKey(dayKey).getTime();
  const end = start + 86400000;

  let n = Math.max(
    1,
    Math.floor((start - last.getTime()) / interval) + 1
  );

  const result = [];

  for (let i = 0; i < 200; i++, n++) {
    const due = new Date(last.getTime() + n * interval);

    if (due.getTime() >= end) break;

    if (due.getTime() >= start) {
      result.push(due);
    }
  }

  return result;
}

function allAgendaItems(dayKey) {
  return medicines.flatMap(m =>
    occurrencesForDay(m, dayKey).map(dueAt => ({
      med: m,
      dueAt,
      status: getStatus(m.id, dueAt)
    }))
  ).sort((a, b) => a.dueAt - b.dueAt);
}

function statusLabel(status) {
  return ({
    tomada: 'Tomada',
    pulada: 'Pulada',
    atrasada: 'Atrasada',
    agendada: 'Agendada'
  })[status] || status;
}

/* Notificações: mantido o sistema de lembretes */

async function ensureNotificationChannel() {
  if (channelReady) return;

  await LocalNotifications.createChannel({
    id: 'dose-alerts',
    name: 'Lembretes de medicamentos',
    description: 'Lembretes dos horários cadastrados no DoseCerta',
    importance: 5,
    visibility: 1,
    sound: 'default'
  });

  channelReady = true;
}

function hash(str) {
  let h = 0;

  for (let i = 0; i < str.length; i++) {
    h = ((h << 5) - h + str.charCodeAt(i)) | 0;
  }

  return h;
}

function notificationId(key, usedIds) {
  let id = Math.abs(hash(key)) % 2147483647;

  if (id === 0) id = 1;

  while (usedIds.has(id)) {
    id = id >= 2147483647 ? 1 : id + 1;
  }

  usedIds.add(id);
  return id;
}

async function refreshNotifications() {
  if (!Capacitor.isNativePlatform()) {
    return { ok: false, message: 'O aplicativo precisa estar instalado no Android.' };
  }

  try {
    const permission = await LocalNotifications.checkPermissions();

    if (permission.display !== 'granted') {
      return {
        ok: false,
        message: 'A permissão para mostrar notificações não está concedida.'
      };
    }

    const exact = await LocalNotifications.checkExactNotificationSetting();

    if (exact.exact_alarm !== 'granted') {
      return {
        ok: false,
        message: 'A autorização para alarmes exatos não está concedida.'
      };
    }

    await ensureNotificationChannel();

    const pending = await LocalNotifications.getPending();

    if (pending.notifications.length) {
      await LocalNotifications.cancel({
        notifications: pending.notifications
      });
    }

    const notifications = [];
    const usedIds = new Set();
    const now = Date.now();

    medicines.forEach(med => {
      const last = parseLocal(med.lastDose);
      const interval = Number(med.intervalHours) * 3600000;

      if (!last || !Number.isFinite(interval) || interval <= 0) {
        return;
      }

      let occurrenceNumber = Math.max(
        1,
        Math.floor((now - last.getTime()) / interval) + 1
      );

      for (let i = 0; i < 20; i++) {
        const occurrence = new Date(
          last.getTime() + occurrenceNumber * interval
        );

        occurrenceNumber++;

        if (occurrence.getTime() <= now) continue;

        const id = notificationId(
          `${med.id}-${occurrence.getTime()}`,
          usedIds
        );

        notifications.push({
          id,
          title: `Hora do medicamento: ${med.name}`,
          body: 'Lembrete de horário cadastrado no DoseCerta.',
          channelId: 'dose-alerts',
          schedule: {
            at: occurrence,
            allowWhileIdle: true
          },
          extra: {
            medicineId: med.id
          }
        });
      }
    });

    if (!notifications.length) {
      return {
        ok: true,
        scheduled: 0,
        message: 'Não há horários futuros para agendar.'
      };
    }

    const result = await LocalNotifications.schedule({
      notifications
    });

    const confirmed = result.notifications?.length ?? 0;

    return {
      ok: confirmed > 0,
      scheduled: confirmed,
      message: confirmed > 0
        ? `${confirmed} lembrete(s) agendado(s).`
        : 'O sistema não confirmou nenhum agendamento.'
    };

  } catch (err) {
    console.warn('Erro ao atualizar notificações:', err);

    return {
      ok: false,
      message: `Erro ao agendar: ${err?.message || 'erro desconhecido'}.`
    };
  }
}

async function enableNotifications() {
  if (!Capacitor.isNativePlatform()) {
    alert('As notificações ficam disponíveis quando o DoseCerta estiver instalado como aplicativo Android.');
    return;
  }

  try {
    let permission = await LocalNotifications.checkPermissions();

    if (permission.display !== 'granted') {
      permission = await LocalNotifications.requestPermissions();
    }

    if (permission.display !== 'granted') {
      alert('A permissão para mostrar notificações não foi concedida. Ative-a nas configurações do Android.');
      return;
    }

    let exact = await LocalNotifications.checkExactNotificationSetting();

    if (exact.exact_alarm !== 'granted') {
      alert('O Android precisa autorizar os alarmes exatos. Na próxima tela, ative essa autorização e volte ao DoseCerta.');

      await LocalNotifications.changeExactNotificationSetting();

      exact = await LocalNotifications.checkExactNotificationSetting();

      if (exact.exact_alarm !== 'granted') {
        alert('A autorização de alarmes exatos ainda não está ativa. Ative-a e toque novamente em Lembretes.');
        return;
      }
    }

    const result = await refreshNotifications();

    if (!result.ok) {
      alert(result.message);
      return;
    }

    if (!result.scheduled) {
      alert('Não encontrei horários futuros para agendar. Confira os horários cadastrados.');
      return;
    }

    alert(`Tudo certo! O DoseCerta confirmou ${result.scheduled} lembrete(s) agendado(s).`);

  } catch (err) {
    console.warn('Erro ao ativar notificações:', err);
    alert(`Não foi possível ativar os lembretes: ${err?.message || 'erro desconhecido'}.`);
  }
}

/* Cadastro e edição de medicamentos */

function openMedicineForm(id = null) {
  const med = medicines.find(m => m.id === id);
  const modal = document.querySelector('#modal');
  const now = new Date();

  modal.innerHTML = `
    <div class="modal-card">
      <div class="modal-head">
        <div>
          <span class="eyebrow">${med ? 'EDITAR CADASTRO' : 'NOVO CADASTRO'}</span>
          <h2>${med ? 'Editar medicamento' : 'Adicionar medicamento'}</h2>
        </div>
        <button class="icon-btn" id="closeModal">×</button>
      </div>

      <form id="medicineForm">
        <label>
          Nome do medicamento
          <input name="name" required maxlength="60"
            value="${escapeHtml(med?.name || '')}"
            placeholder="Ex.: Medicamento">
        </label>

        <label>
          Última dose
          <input name="lastDose" type="datetime-local" required
            value="${med?.lastDose || toLocalInput(now)}">
        </label>

        <label>
          Intervalo entre as doses (horas)
          <input name="intervalHours" type="number" min="0.25"
            max="168" step="0.25" required
            value="${med?.intervalHours ?? 8}">
        </label>

        <label>
          Observação (opcional)
          <input name="note" maxlength="100"
            value="${escapeHtml(med?.note || '')}"
            placeholder="Observação">
        </label>

        <div class="form-grid">
          <label>
            Estoque atual (unidades)
            <input name="stock" type="number" min="0" step="0.01"
              value="${med?.stock ?? ''}"
              placeholder="Não controlar">
          </label>

          <label>
            Quantidade por dose
            <input name="quantityPerDose" type="number" min="0.01"
              step="0.01" required
              value="${med?.quantityPerDose ?? 1}">
          </label>
        </div>

        <label>
          Aviso de estoque baixo (unidades)
          <input name="stockAlert" type="number" min="0" step="0.01"
            value="${med?.stockAlert ?? 5}">
        </label>

        <p class="form-note">
          Cadastre somente os horários e intervalos indicados na sua
          prescrição. O estoque só será descontado ao registrar uma
          dose como tomada.
        </p>

        <button class="primary-btn full" type="submit">
          Salvar medicamento
        </button>
      </form>
    </div>
  `;

  modal.classList.remove('hidden');

  document.querySelector('#closeModal').addEventListener('click', closeModal);

  modal.onclick = e => {
    if (e.target === modal) closeModal();
  };

  document.querySelector('#medicineForm').addEventListener('submit', e => {
    e.preventDefault();

    const data = new FormData(e.currentTarget);

    const name = String(data.get('name')).trim();
    const lastDose = String(data.get('lastDose'));
    const intervalHours = Number(data.get('intervalHours'));
    const stockRaw = String(data.get('stock')).trim();
    const quantityPerDose = Number(data.get('quantityPerDose'));
    const stockAlert = Number(data.get('stockAlert') || 0);

    if (
      !name ||
      !parseLocal(lastDose) ||
      !Number.isFinite(intervalHours) ||
      intervalHours <= 0 ||
      intervalHours > 168 ||
      !Number.isFinite(quantityPerDose) ||
      quantityPerDose <= 0 ||
      (
        stockRaw !== '' &&
        (!Number.isFinite(Number(stockRaw)) || Number(stockRaw) < 0)
      )
    ) {
      alert('Confira os dados informados.');
      return;
    }

    const payload = {
      id: med?.id || makeId(),
      name,
      lastDose,
      intervalHours,
      note: String(data.get('note')).trim(),
      stock: stockRaw === '' ? null : Number(stockRaw),
      quantityPerDose,
      stockAlert
    };

    if (med) {
      medicines = medicines.map(m => m.id === med.id ? payload : m);
    } else {
      medicines.unshift(payload);
    }

    closeModal();
    persistAndRender();
  });
}

function closeModal() {
  const modal = document.querySelector('#modal');
  modal.classList.add('hidden');
  modal.innerHTML = '';
}

function deleteMedicine(id) {
  const med = medicines.find(m => m.id === id);

  if (!med || !confirm(`Excluir ${med.name}? O histórico já registrado será mantido.`)) {
    return;
  }

  medicines = medicines.filter(m => m.id !== id);
  persistAndRender();
}

/* Backup e restauração */

function exportBackup() {
  const payload = {
    app: 'DoseCerta',
    version: 2,
    exportedAt: new Date().toISOString(),
    medicines,
    history,
    settings
  };

  const blob = new Blob(
    [JSON.stringify(payload, null, 2)],
    { type: 'application/json' }
  );

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');

  a.href = url;
  a.download = `dosecerta-backup-${localDateKey(new Date())}.json`;
  a.click();

  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function importBackup(file) {
  if (!file) return;

  const reader = new FileReader();

  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);

      if (
        data.app !== 'DoseCerta' ||
        !Array.isArray(data.medicines) ||
        !Array.isArray(data.history)
      ) {
        throw new Error('Arquivo inválido');
      }

      if (!confirm(
        `Restaurar ${data.medicines.length} medicamento(s) e ${data.history.length} registro(s)? Os dados atuais serão substituídos.`
      )) {
        return;
      }

      medicines = data.medicines.map(m => ({
        ...m,
        stock: m.stock === undefined ? null : m.stock,
        quantityPerDose: Number(m.quantityPerDose) || 1,
        stockAlert: Number(m.stockAlert) || 5
      }));

      history = data.history.map(h => ({
        ...h,
        status: h.status || 'tomada',
        scheduledAt: h.scheduledAt || h.takenAt || new Date().toISOString(),
        recordedAt: h.recordedAt || h.takenAt || new Date().toISOString()
      }));

      settings = {
        ...settings,
        ...(data.settings || {})
      };

      persistAndRender();
      alert('Backup restaurado com sucesso.');

    } catch {
      alert('Não foi possível restaurar: arquivo inválido ou incompatível.');
    }
  };

  reader.readAsText(file);
}

/* Telas */

function renderAgenda() {
  const items = allAgendaItems(settings.selectedDate);

  const taken = items.filter(i => i.status === 'tomada').length;
  const late = items.filter(i => i.status === 'atrasada').length;
  const skipped = items.filter(i => i.status === 'pulada').length;

  return `
    <section class="section-head">
      <div>
        <span class="eyebrow">ROTINA</span>
        <h2>Agenda diária</h2>
      </div>
      <span class="day-count">${items.length} dose(s)</span>
    </section>

    <div class="date-toolbar">
      <button class="outline-btn" id="prevDay">‹</button>
      <input type="date" id="agendaDate" value="${settings.selectedDate}">
      <button class="outline-btn" id="nextDay">›</button>
      <button class="text-btn" id="todayBtn">Hoje</button>
    </div>

    <div class="stats-strip">
      <div><strong>${taken}</strong><small>Tomadas</small></div>
      <div><strong>${late}</strong><small>Atrasadas</small></div>
      <div><strong>${skipped}</strong><small>Puladas</small></div>
    </div>

    ${
      items.length
        ? `
          <div class="agenda-list">
            ${items.map(({ med, dueAt, status }) => `
              <article class="agenda-item">
                <div class="agenda-time">
                  ${fmtTime(dueAt)}
                  <small>${statusLabel(status)}</small>
                </div>

                <div class="agenda-detail">
                  <strong>${escapeHtml(med.name)}</strong>
                  <small>${escapeHtml(med.note || `Intervalo: ${med.intervalHours}h`)}</small>
                </div>

                <div class="agenda-actions">
                  ${
                    status === 'tomada'
                      ? '<span class="status-pill taken">Tomada</span>'
                      : status === 'pulada'
                        ? '<span class="status-pill skipped">Pulada</span>'
                        : `
                          <button class="mini-btn"
                            data-dose-action="tomada"
                            data-med="${med.id}"
                            data-due="${dueAt.getTime()}">
                            Tomada
                          </button>

                          <button class="mini-btn secondary"
                            data-dose-action="pulada"
                            data-med="${med.id}"
                            data-due="${dueAt.getTime()}">
                            Pular
                          </button>
                        `
                  }
                </div>
              </article>
            `).join('')}
          </div>
        `
        : `
          <div class="empty-state">
            <div class="empty-icon">◷</div>
            <h3>Nenhuma dose prevista</h3>
            <p>Não há horários calculados para este dia com os cadastros atuais.</p>
          </div>
        `
    }
  `;
}

function renderMedicines() {
  const filtered = medicines.filter(m => {
    const matches = m.name.toLowerCase().includes(searchTerm.toLowerCase());
    const next = nextDose(parseLocal(m.lastDose), m.intervalHours);
    const status = next && next.getTime() < Date.now()
      ? 'atrasada'
      : 'agendada';

    return matches &&
      (statusFilter === 'todos' || statusFilter === status);
  }).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));

  return `
    <section class="section-head">
      <div>
        <span class="eyebrow">CADASTROS</span>
        <h2>Medicamentos</h2>
      </div>
      <button class="primary-btn" id="addBtn">＋ Adicionar</button>
    </section>

    <div class="search-tools">
      <input id="searchInput" type="search"
        placeholder="Buscar medicamento..."
        value="${escapeHtml(searchTerm)}">

      <select id="statusFilter">
        <option value="todos" ${statusFilter === 'todos' ? 'selected' : ''}>Todos os status</option>
        <option value="agendada" ${statusFilter === 'agendada' ? 'selected' : ''}>Agendada</option>
        <option value="atrasada" ${statusFilter === 'atrasada' ? 'selected' : ''}>Atrasada</option>
      </select>
    </div>

    ${
      filtered.length
        ? `
          <div class="med-list">
            ${filtered.map(m => {
              const next = nextDose(parseLocal(m.lastDose), m.intervalHours);
              const overdue = next && next.getTime() <= Date.now();
              const low = m.stock !== null &&
                Number(m.stock) <= Number(m.stockAlert || 0);

              return `
                <article class="med-card">
                  <div class="med-card-top">
                    <div class="med-icon">${capsuleSvg()}</div>

                    <div class="med-title">
                      <h3>${escapeHtml(m.name)}</h3>
                      <span>${escapeHtml(m.note || `Intervalo: ${m.intervalHours}h`)}</span>
                    </div>

                    <button class="dots" data-edit="${m.id}">•••</button>
                  </div>

                  <div class="dose-info">
                    <div>
                      <span class="eyebrow">PRÓXIMO HORÁRIO</span>
                      <strong>${fmt(next)}</strong>
                      <small class="${overdue ? 'overdue' : ''}">${relative(next)}</small>
                    </div>

                    <div class="interval">
                      <span class="eyebrow">INTERVALO</span>
                      <strong>${m.intervalHours}h</strong>
                    </div>
                  </div>

                  <div class="stock-line">
                    <span>
                      Estoque:
                      <b>${m.stock === null ? 'Não controlado' : `${m.stock} un.`}</b>
                    </span>
                    ${low ? '<em>Estoque baixo</em>' : ''}
                  </div>

                  <div class="last-dose">
                    Última dose de referência: ${fmt(parseLocal(m.lastDose))}
                  </div>

                  <div class="card-actions">
                    <button class="taken-btn"
                      data-taken-next="${m.id}"
                      data-due="${next?.getTime() || ''}">
                      ✓ Registrar próxima dose
                    </button>

                    <button class="text-btn" data-delete="${m.id}">
                      Excluir
                    </button>
                  </div>
                </article>
              `;
            }).join('')}
          </div>
        `
        : `
          <div class="empty-state">
            <h3>Nenhum resultado</h3>
            <p>Revise a busca ou cadastre um medicamento.</p>
          </div>
        `
    }
  `;
}

function renderHistory() {
  const rows = history.slice().sort(
    (a, b) => new Date(b.recordedAt) - new Date(a.recordedAt)
  );

  return `
    <section class="section-head">
      <div>
        <span class="eyebrow">REGISTROS</span>
        <h2>Histórico de doses</h2>
      </div>
      <span class="day-count">${rows.length} registro(s)</span>
    </section>

    ${
      rows.length
        ? `
          <div class="history-list">
            ${rows.slice(0, 300).map(h => `
              <div class="history-item">
                <span class="history-check ${h.status}">
                  ${h.status === 'tomada' ? '✓' : h.status === 'pulada' ? '–' : '!'}
                </span>

                <div class="history-text">
                  <strong>${escapeHtml(h.medicineName)}</strong>
                  <small>${statusLabel(h.status)} · Prevista: ${fmt(new Date(h.scheduledAt))}</small>
                  <small>Registrada: ${fmt(new Date(h.recordedAt))}</small>
                </div>

                <button class="text-btn" data-undo="${h.id}">
                  Corrigir
                </button>
              </div>
            `).join('')}
          </div>
        `
        : '<p class="muted">Ainda não há registros.</p>'
    }
  `;
}

function renderStats() {
  const taken = history.filter(h => h.status === 'tomada').length;
  const skipped = history.filter(h => h.status === 'pulada').length;

  const late = allAgendaItems(localDateKey(new Date()))
    .filter(i => i.status === 'atrasada').length;

  const total = taken + skipped;
  const rate = total ? Math.round(taken / total * 100) : 0;

  const low = medicines.filter(m =>
    m.stock !== null &&
    Number(m.stock) <= Number(m.stockAlert || 0)
  );

  return `
    <section class="section-head">
      <div>
        <span class="eyebrow">VISÃO GERAL</span>
        <h2>Calendário e estatísticas</h2>
      </div>
    </section>

    <div class="stats-grid">
      <div class="stat-card"><small>Doses tomadas</small><strong>${taken}</strong></div>
      <div class="stat-card"><small>Doses puladas</small><strong>${skipped}</strong></div>
      <div class="stat-card"><small>Atrasadas hoje</small><strong>${late}</strong></div>
      <div class="stat-card"><small>Adesão registrada</small><strong>${rate}%</strong></div>
    </div>

    <section class="panel">
      <h3>Calendário</h3>

      <label class="calendar-label">
        Escolha um dia
        <input type="date" id="calendarDate" value="${settings.selectedDate}">
      </label>

      <button class="outline-btn" id="openCalendarDay">
        Ver agenda deste dia
      </button>

      <p class="muted">
        A porcentagem considera somente registros marcados como tomadas
        ou puladas; não é uma avaliação médica.
      </p>
    </section>

    <section class="panel">
      <h3>Estoque baixo</h3>

      ${
        low.length
          ? low.map(m => `
              <p class="stock-alert-row">
                ${escapeHtml(m.name)}
                <strong>${m.stock} un.</strong>
              </p>
            `).join('')
          : '<p class="muted">Nenhum medicamento abaixo do limite de alerta cadastrado.</p>'
      }
    </section>
  `;
}

function renderBackup() {
  return `
    <section class="section-head">
      <div>
        <span class="eyebrow">SEUS DADOS</span>
        <h2>Backup e restauração</h2>
      </div>
    </section>

    <div class="panel">
      <h3>Salvar uma cópia</h3>
      <p>
        Exporte medicamentos, horários, estoque e histórico em um arquivo JSON.
        Guarde esse arquivo em local seguro.
      </p>
      <button class="primary-btn" id="exportBackup">
        Exportar backup
      </button>
    </div>

    <div class="panel">
      <h3>Restaurar dados</h3>
      <p>
        A restauração substitui os dados atuais pelos dados do arquivo escolhido.
        Faça um backup antes, se quiser conservar o estado atual.
      </p>

      <label class="file-label">
        Selecionar arquivo JSON
        <input type="file" id="backupFile" accept="application/json,.json">
      </label>
    </div>
  `;
}

/* Renderização principal */

function render() {
  const upcoming = medicines.map(m => ({
    ...m,
    next: nextDose(parseLocal(m.lastDose), m.intervalHours)
  })).sort((a, b) =>
    (a.next?.getTime() ?? Infinity) -
    (b.next?.getTime() ?? Infinity)
  );

  const featured = upcoming[0];

  app.innerHTML = `
    <header class="topbar">
      <a class="brand" href="#">
        <span class="brand-mark">${capsuleSvg()}</span>
        <span>Dose<span class="brand-light">Certa</span></span>
      </a>

      <button class="notify-btn" id="notifyBtn">
        ♧ <span>Lembretes</span>
      </button>
    </header>

    <main>
      ${
        featured
          ? `
            <section class="next-dose-card">
              <div class="next-dose-top">
                <span class="eyebrow">PRÓXIMA DOSE</span>
                <span class="dose-status ${featured.next && featured.next <= new Date() ? 'status-overdue' : ''}">
                  ${featured.next && featured.next <= new Date() ? 'HORÁRIO PASSADO' : 'AGENDADA'}
                </span>
              </div>

              <div class="next-dose-content">
                <div class="next-dose-info">
                  <h1>${escapeHtml(featured.name)}</h1>
                  <p>${escapeHtml(featured.note || `Intervalo cadastrado: ${featured.intervalHours}h`)}</p>
                </div>

                <div class="next-dose-time">${fmtTime(featured.next)}</div>

                <div class="countdown-row">
                  <span class="main-countdown"
                    data-countdown
                    data-next="${featured.next?.getTime() || ''}">
                    ${relative(featured.next)}
                  </span>
                  <span class="next-dose-date">${fmt(featured.next)}</span>
                </div>
              </div>
            </section>
          `
          : `
            <section class="next-dose-card next-dose-empty">
              <span class="eyebrow">DOSECERTA</span>
              <h1>Seus horários, sob controle.</h1>
              <p>Cadastre medicamentos para organizar seus horários e lembretes.</p>
              <button class="primary-btn" id="heroAdd">
                ＋ Adicionar medicamento
              </button>
            </section>
          `
      }

      <nav class="tab-bar">
        <button data-tab="agenda" class="${activeTab === 'agenda' ? 'active' : ''}">Agenda</button>
        <button data-tab="medicines" class="${activeTab === 'medicines' ? 'active' : ''}">Medicamentos</button>
        <button data-tab="history" class="${activeTab === 'history' ? 'active' : ''}">Histórico</button>
        <button data-tab="stats" class="${activeTab === 'stats' ? 'active' : ''}">Estatísticas</button>
        <button data-tab="backup" class="${activeTab === 'backup' ? 'active' : ''}">Backup</button>
      </nav>

      ${
        activeTab === 'agenda'
          ? renderAgenda()
          : activeTab === 'medicines'
            ? renderMedicines()
            : activeTab === 'history'
              ? renderHistory()
              : activeTab === 'stats'
                ? renderStats()
                : renderBackup()
      }

      <p class="disclaimer">
        <strong>Atenção:</strong>
        DoseCerta é um organizador de horários. Não indica medicamentos,
        doses ou intervalos. Siga a prescrição e as orientações do profissional
        de saúde. Durante os testes, mantenha também os lembretes independentes
        do aparelho.
      </p>
    </main>

    <footer>
      <span class="footer-mark">DOSECERTA</span> · ORGANIZAÇÃO DE HORÁRIOS
    </footer>

    <div id="modal" class="modal hidden"></div>
  `;

  document.querySelector('.brand')?.addEventListener('click', e => {
    e.preventDefault();
    activeTab = 'agenda';
    render();
  });

  document.querySelector('#notifyBtn')?.addEventListener('click', enableNotifications);
  document.querySelector('#heroAdd')?.addEventListener('click', () => openMedicineForm());
  document.querySelector('#addBtn')?.addEventListener('click', () => openMedicineForm());

  document.querySelectorAll('[data-tab]').forEach(b => {
    b.addEventListener('click', () => {
      activeTab = b.dataset.tab;
      render();
    });
  });

  document.querySelectorAll('[data-edit]').forEach(b => {
    b.addEventListener('click', () => openMedicineForm(b.dataset.edit));
  });

  document.querySelectorAll('[data-delete]').forEach(b => {
    b.addEventListener('click', () => deleteMedicine(b.dataset.delete));
  });

  document.querySelectorAll('[data-dose-action]').forEach(b => {
    b.addEventListener('click', () =>
      markDose(b.dataset.med, b.dataset.due, b.dataset.doseAction)
    );
  });

  document.querySelectorAll('[data-taken-next]').forEach(b => {
    b.addEventListener('click', () => {
      if (b.dataset.due) {
        markDose(b.dataset.takenNext, b.dataset.due, 'tomada');
      }
    });
  });

  document.querySelectorAll('[data-undo]').forEach(b => {
    b.addEventListener('click', () => correctRecord(b.dataset.undo));
  });

  document.querySelector('#agendaDate')?.addEventListener('change', e => {
    settings.selectedDate = e.target.value;
    save();
    render();
  });

  document.querySelector('#prevDay')?.addEventListener('click', () => shiftDate(-1));
  document.querySelector('#nextDay')?.addEventListener('click', () => shiftDate(1));

  document.querySelector('#todayBtn')?.addEventListener('click', () => {
    settings.selectedDate = localDateKey(new Date());
    save();
    render();
  });

  document.querySelector('#searchInput')?.addEventListener('input', e => {
    searchTerm = e.target.value;
    const pos = e.target.selectionStart;

    render();

    const input = document.querySelector('#searchInput');
    input.focus();
    input.setSelectionRange(pos, pos);
  });

  document.querySelector('#statusFilter')?.addEventListener('change', e => {
    statusFilter = e.target.value;
    render();
  });

  document.querySelector('#exportBackup')?.addEventListener('click', exportBackup);

  document.querySelector('#backupFile')?.addEventListener('change', e => {
    importBackup(e.target.files[0]);
  });

  document.querySelector('#calendarDate')?.addEventListener('change', e => {
    settings.selectedDate = e.target.value;
    save();
  });

  document.querySelector('#openCalendarDay')?.addEventListener('click', () => {
    activeTab = 'agenda';
    render();
  });

  updateCountdowns();
}

function shiftDate(amount) {
  const date = dateFromKey(settings.selectedDate);
  date.setDate(date.getDate() + amount);

  settings.selectedDate = localDateKey(date);

  save();
  render();
}

function correctRecord(id) {
  const item = history.find(h => h.id === id);

  if (!item) return;

  if (!confirm(
    'Remover este registro do histórico? Se era uma dose tomada, o estoque não será devolvido automaticamente.'
  )) {
    return;
  }

  history = history.filter(h => h.id !== id);
  persistAndRender();
}

function updateCountdowns() {
  document.querySelectorAll('[data-countdown]').forEach(element => {
    const timestamp = Number(element.dataset.next);

    if (!timestamp) return;

    const date = new Date(timestamp);
    element.textContent = relative(date);
    element.classList.toggle('overdue', timestamp <= Date.now());
  });
}

/* Inicialização */

render();

setInterval(updateCountdowns, 1000);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    updateCountdowns();
    refreshNotifications();
  }
});

if (Capacitor.isNativePlatform()) {
  refreshNotifications();
}
